import React from "react";

const Test2 = () => {
  return (
    <div className="flex w-full border justify-between">
      Test2
      <div className="">Test2</div>
    </div>
  );
};

export default Test2;
