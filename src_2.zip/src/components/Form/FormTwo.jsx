import React from "react";

const FormTwo = () => {
  return <div>FormTwo</div>;
};

export default FormTwo;
